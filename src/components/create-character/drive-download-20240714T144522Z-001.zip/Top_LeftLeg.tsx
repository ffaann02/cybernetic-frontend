const Top_LeftLeg = () => {
  return (
    <div>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 107.56 211.26">
    <defs>
        {/* <style>.cls-1{fill:#58595b;}.cls-2{fill:#27aae1;}</style> */}
    </defs>
    <g id="Layer_2" data-name="Layer 2">
        <g id="Layer_3" data-name="Layer 3">
            <g id="TopLeftLeg">
                <path className="cls-1" fill="#58595b"
                    d="M42.82,0H64.74a42.81,42.81,0,0,1,42.81,42.81V208.93a2.33,2.33,0,0,1-2.33,2.33H2.34A2.33,2.33,0,0,1,0,208.93V42.81A42.81,42.81,0,0,1,42.82,0Z" />
                <path className="cls-2" fill="#27aae1"
                    d="M107.56,194.37v14.56a2.33,2.33,0,0,1-2.34,2.33H2.34A2.33,2.33,0,0,1,0,208.93V194.37Z" />
            </g>
        </g>
    </g>
</svg>
    </div>
  );
};
export default Top_LeftLeg;
